# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for rpmsg_str_echo_freertos_example.
